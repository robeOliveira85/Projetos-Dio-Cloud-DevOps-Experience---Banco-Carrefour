# [Formação Linux Fundamentals](https://web.dio.me/track/formacao-linux-fundamentals)

- ##### [Infraestrutura como Código: Script de Criação de Estrutura de Usuários, Diretórios e Permissões](https://web.dio.me/project/infraestrutura-como-codigo-script-de-criacao-de-estrutura-de-usuarios-diretorios-e-permissoes/learning/c83c768d-0350-4503-84dc-de52f1e9bd8d) :heavy_check_mark:

- ##### [Desafio de Projeto: Infraestrutura como Código - Script de Provisionamento de um Servidor Web (Apache)](https://web.dio.me/project/infraestrutura-como-codigo-script-de-provisionamento-de-um-servidor-web-apache/learning/29d22f7e-e72c-4a50-8b25-a9af4a3a8471) :heavy_check_mark:
