# Desafio de Projeto

## Infraestrutura como Código: Script de Provisionamento de um Servidor Web (Apache)

O script permite que você faça uma instalação "automatizada" do apache, e faça a extração de um pacote "zip".

A variável DISTRO serve para definir a distribuição que você está instalando, a mesma poderia ser identificada automaticamente, caso alguém goste do script irei fazer novas implementações nele.
A variável DEFAULT_DIR serve para definir o diretório onde o pacote deverá ser instalado após o download.
A variável PKG_LINK define o link para download do pacote.
A variável PKG_NAME define com que nome esse arquivo baixado será salvo.