# [Formação Docker Fundamentals](https://web.dio.me/track/formacao-docker-fundamentals)

- ##### [Criando um Container de uma Aplicação WEB](https://web.dio.me/project/criando-um-container-de-uma-aplicacao-web/learning/ab0654f1-b0fe-4cc6-8632-533d07887bac) :heavy_check_mark:

- ##### [Definição de um Cluster Swarm Local com o Vagrant](https://web.dio.me/project/definicao-de-um-cluster-swarm-local-com-o-vagrant/learning/406dc0e5-8784-466e-ae61-a460305f401d) :heavy_check_mark:
