## [Formação Scrum Master Certification](https://github.com/gmurilo/dio/tree/main/formacao-scrum-master)

- ##### [Scrum: Analisando Cases de Sucesso](https://web.dio.me/project/compreendendo-o-scrum-na-pratica/learning/b7a5d54a-68d7-4a5b-bd75-fc7be43c2d42) :heavy_check_mark:

- ##### [Completando o Framework Scrum](https://web.dio.me/project/completando-o-framework-scrum/learning/57abfa35-6a9c-4456-acae-c81a095ff113) :heavy_check_mark:
