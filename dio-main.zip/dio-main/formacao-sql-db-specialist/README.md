# [Formação SQL Database Specialist](https://web.dio.me/track/formacao-sql-db-specialist)

- ##### [Refinando um Projeto Conceitual de Banco de Dados – E-COMMERCE](https://web.dio.me/lab/refinando-um-projeto-conceitual-de-banco-de-dados-e-commerce/learning/0491dff0-c197-421f-af79-daa4933dfa38)

- ##### [Construindo um Esquema Conceitual para Banco De dados](https://web.dio.me/project/construindo-um-esquema-conceitual-do-zero/learning/dc17e958-fada-4450-b1c2-d89cc7afabd0)

- ##### [Construa um Projeto Lógico de Banco de Dados do Zero](https://web.dio.me/project/construa-um-projeto-logico-de-banco-de-dados-do-zero/learning/e22c99ed-c252-4f0e-8787-62b89b68f83f)

- ##### [Personalizando o Banco de Dados com Índices e Procedures](https://web.dio.me/lab/personalizando-o-banco-de-dados-com-indices-e-procedures/learning/b6a20d7f-7457-4ae1-9fb0-952eacaa8a88)

- ##### [Personalizando Acessos e Automatizando ações no MySQL](https://web.dio.me/lab/personalizando-acessos-e-automatizando-acoes-no-mysql/learning/5fe40d04-7d5e-4854-b551-61d06cac7519)

- ##### [Criando Transações, Executando Backup e Recovery de Banco de Dados](https://web.dio.me/project/criando-transacoes-executando-backup-e-recovery-de-banco-de-dados/learning/792d0ce7-f189-4e90-a191-eaa8f3f5c8d9)