# [Formação HTML Web Developer](https://web.dio.me/track/formacao-html-web-developer)
- ##### [Criar Uma Página Web Utilizando as Tags Aprendidas](https://web.dio.me/lab/criar-uma-pagina-web-utilizando-as-tags-aprendidas/learning/fc56c26e-95a4-419d-a5bf-48826e676952) :heavy_check_mark:

- ##### [Criando seu Primeiro Site Completo com HTML](https://web.dio.me/project/criando-seu-primeiro-site-completo-com-html/learning/d6ceca11-2858-4a8f-a76f-4d63a91cc603) :heavy_check_mark:

- ##### [Recriando o Wikipedia com Layout Moderno](https://web.dio.me/project/recriando-o-wikipedia-com-layout-moderno/learning/fb2493c1-bc7a-4cbf-91f8-2927f2a68adb) :heavy_check_mark:
