## [Formação Linux Experience](https://web.dio.me/track/linux-experience) :heavy_check_mark:

- ##### [Criando seu Primeiro Repositório no GitHub Para Compartilhar Seu Progresso](https://web.dio.me/project/criando-seu-primeiro-repositorio-no-github-para-compartilhar-seu-progresso/learning/a6e285fa-b9a0-4bc2-8353-7b729dabcf0c) :heavy_check_mark:

- ##### [Infraestrutura como Código: Script de Criação de Estrutura de Usuários, Diretórios e Permissões](https://web.dio.me/project/infraestrutura-como-codigo-script-de-criacao-de-estrutura-de-usuarios-diretorios-e-permissoes/learning/c83c768d-0350-4503-84dc-de52f1e9bd8d) :heavy_check_mark:

- ##### [Desafio de Projeto: Infraestrutura como Código - Script de Provisionamento de um Servidor Web (Apache)](https://web.dio.me/project/infraestrutura-como-codigo-script-de-provisionamento-de-um-servidor-web-apache/learning/29d22f7e-e72c-4a50-8b25-a9af4a3a8471) :heavy_check_mark:

- ##### [Docker: Utilização Prática no Cenário de Microsserviços](https://web.dio.me/project/docker-utilizacao-pratica-no-cenario-de-microsservicos/learning/d151f94a-d53c-4ad3-b35a-333307faaf24) :heavy_check_mark:
