# Repositórios de projetos realizados para os labs da DIO

## [Bootcamp - Geração Tech Unimed-BH - Ciência de Dados](https://web.dio.me/track/geracao-tech-unimed-bh-ciencia-de-dados)

## [Bootcamp - NTT DATA Diversidade em Tech](https://web.dio.me/track/ntt-data-diversidade-em-tech)

## [Cloud DevOps Experience - Banco Carrefour](https://web.dio.me/track/cloud-devops-experience-banco-carrefour) 

## [Cloud Fullstack Bootcamp - Warburg Pincus](https://github.com/gmurilo/dio/tree/main/formacao-css-web-developer)

[DIO - Cloud Fullstack Bootcamp - Warburg Pincus](https://web.dio.me/track/64d0fafa-be32-4f17-a0e9-4accc36cf83f)

## [Formação CSS Web Developer](https://github.com/gmurilo/dio/tree/main/formacao-css-web-developer) :heavy_check_mark:

[DIO - Formação CSS Web Developer](https://app.dio.me/api/tracks/formacao-css-web-developer)

## [Formação Docker Fundamentals](https://github.com/gmurilo/dio/tree/main/formacao-docker-fundamentals) :heavy_check_mark:

[DIO - Formação Docker Fundamentals](https://web.dio.me/track/formacao-docker-fundamentals)

## [Formação HTML Web Developer](https://github.com/gmurilo/dio/tree/main/formacao-html-web-developer) :heavy_check_mark:

[DIO - Formação HTML Web Developer](https://web.dio.me/track/formacao-html-web-developer)

## [Formação JavaScript Developer](https://github.com/gmurilo/dio/tree/main/formacao-javascript-developer) :heavy_check_mark:

[DIO - Formação JavaScript Developer](https://web.dio.me/track/formacao-javascript-developer)

## [Formação Linux Fundamentals](https://github.com/gmurilo/dio/tree/main/formacao-linux-fundamentals) :heavy_check_mark:

[DIO - Formação Linux Fundamentals](https://web.dio.me/track/formacao-linux-fundamentals)

## [Formação Linux Experience](https://github.com/gmurilo/dio/tree/main/formacao-linux-experience) :heavy_check_mark:

[DIO - Linux Experience](https://web.dio.me/track/linux-experience)

## [Formação PHP Experience](https://github.com/gmurilo/dio/tree/main/formacao-php-experience) :heavy_check_mark:

[DIO - Formação PHP Experience](https://web.dio.me/track/formacao-php-experience)

## [Formação Formação Python Developer](https://github.com/gmurilo/dio/tree/main/formacao-python-developer)

[DIO - Formação Python Developer](https://web.dio.me/track/formacao-python-developer)

## [Formação Scrum Master Certification](https://github.com/gmurilo/dio/tree/main/formacao-scrum-master) :heavy_check_mark:

[DIO - Formação Scrum Master Certification](https://web.dio.me/track/formacao-scrum-master)

## [Formação SQL Database Specialist](https://github.com/gmurilo/dio/tree/main/formacao-sql-db-specialist)

[DIO - Formação SQL Database Specialist](https://web.dio.me/track/formacao-sql-db-specialist)

## [Formação TypeScript Fullstack Developer](https://github.com/gmurilo/dio/tree/main/formacao-typescript-fullstack-developer)

[DIO - Formação TypeScript Fullstack Developer](https://web.dio.me/track/formacao-typescript-fullstack-developer)
