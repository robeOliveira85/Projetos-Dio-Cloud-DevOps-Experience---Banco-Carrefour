## [Formação TypeScript Fullstack Developer](https://github.com/gmurilo/dio/tree/main/formacao-typescript-fullstack-developer)

- ##### [Construindo Uma App Simples de Banco Com Typescript](https://web.dio.me/project/construindo-o-dio-bank/learning/cb8eec57-589e-4ee9-98e0-e6725cbc051a) :heavy_check_mark:

- ##### [Criando uma Homepage com React](https://web.dio.me/project/criando-a-homepage-do-dio-bank-com-react/learning/225e4e1b-c77a-4cb0-a5d9-db7a3f756705)

- ##### [Criando a Página Com os Detalhes do Usuário Com React](https://web.dio.me/project/criando-a-pagina-com-os-detalhes-do-usuario-com-react/learning/dfd5c0b2-e3fe-43b2-966c-cff200c6335c)

- ##### [Criando a API do Dio Bank Com Node](https://web.dio.me/project/criando-a-api-do-dio-bank-com-node/learning/b58b8ca5-4f94-4a03-b953-0e1809aa8f9f)
