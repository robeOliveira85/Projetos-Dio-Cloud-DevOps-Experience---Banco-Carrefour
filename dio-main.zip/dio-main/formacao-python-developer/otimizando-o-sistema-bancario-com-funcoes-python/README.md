# Desafio de Projeto

## Otimizando o Sistema Bancário com Funções Python

Criando as funções adicionar usuário e adicionar conta bancária.

Cliente: 
O cliente deverá possuir nome, data de nascimento, cpf e endereço.
O endereço é uma string no formato logradouro, nro, bairro, cidade e sigla do estado.
O cpf deve ser armazenado apenas com números.
Não poderá ser armazenado mais de um cpf igual.

Conta:
O número da conta é sequencial.
O número da agência é fixo.
* O usuário pode ter mais de uma conta
* O número da conta só pode ser associado à um usuário.
