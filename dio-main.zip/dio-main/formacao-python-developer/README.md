# [Formação Python Developer](https://web.dio.me/track/formacao-python-developer)

- ##### [Criando um Sistema Bancário com Python](https://web.dio.me/project/desafio-de-projeto-criando-um-sistema-bancario/learning/fa812356-0da6-4a85-9ffb-8b255748a288) :heavy_check_mark:

- ##### [Otimizando o Sistema Bancário com Funções Python](https://web.dio.me/project/otimizando-o-sistema-bancario-com-funcoes-python/learning/82a55799-cfb8-479d-85a3-4982e29c90ba) :heavy_check_mark:

- ##### [Modelando o Sistema Bancário em POO com Python](https://web.dio.me/project/modelando-o-sistema-bancario-em-poo-com-python/learning/92139fbc-dd1f-44c2-a9dc-61859f246f60) :heavy_check_mark:

- ##### [Integrando Python com SQLite e MongoDB](https://web.dio.me/project/integrando-python-com-sqlite-e-mongodb/learning/eab2d584-6c76-4597-a550-e2ca95ef4d56) :heavy_check_mark:

- ##### [Criando uma API com Flask no Ambiente COLAB](https://web.dio.me/project/criando-uma-api-com-flask-no-ambiente-colab/learning/92e095c6-76d6-4014-b272-4bb0f2948958)

- ##### [Análise de dados com Python e Pandas](https://web.dio.me/project/analise-de-dados-com-python-e-pandas/learning/8cc8c67e-eb34-4254-af7a-c0ff8cf72834)

- ##### [Descomplicando a criação de pacotes de processamento de imagens em Python](https://web.dio.me/project/descomplicando-a-criacao-de-pacotes-de-processamento-de-imagens-em-python/learning/3d3925ad-7a05-4068-9cf9-7f3f7b18e99f)

- ##### [Consumindo a API do Twitter com Python](https://web.dio.me/project/consumindo-a-api-do-twitter-com-python/learning/6702bea4-a270-4e56-b3cd-c320557fd4f9)
