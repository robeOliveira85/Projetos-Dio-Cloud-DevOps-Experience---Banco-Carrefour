# Desafio de Projeto

## Criando um Sistema Bancário com Python

### Criar um sistema bancário contendo as operações de: 
### saque, depósito e extrato.

- ##### depósito:

Apenas será possível o deposito de valores positivos.

- ##### saque:

O limite total de saque é de R$ 1500.00
O limite por saque é de R$ 500.00

- ##### extrato:

O extrato poderá ser consultado com as informações de lançamento