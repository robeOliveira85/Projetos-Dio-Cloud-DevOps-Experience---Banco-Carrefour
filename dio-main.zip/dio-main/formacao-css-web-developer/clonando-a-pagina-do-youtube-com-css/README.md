# Entendendo o Desafio

Neste Desafio você colocará a mão na massa e irá **clonar a página do YouTube** com CSS colocando em prática todos os conceitos aprendidos, principalmente sobre **Flexbox**.

 

**Seja criativo(a) e dê a sua identidade para o Projeto. Lembre-se que para um(a) Profissional de Tecnologia é super importante ter um portfólio sólido e completo.**

 

## **Link do Figma**

Aqui deixamos o link do Design no Figma apresentado pela Expert durante o Desafio para que você o tenha como referência:

**[Desafio de Flexbox](https://www.figma.com/file/lrRWUZPKnqMDZrSDJmZxUS/Desafio-de-Flexbox---DIO?node-id=0%3A1)**

 

 

Bons estudos ![wink](https://app.digitalinnovation.one/static/ckeditor/ckeditor/plugins/smiley/images/wink_smile.png)

 