# Entendendo o Desafio

Neste Desafio você colocará a mão na massa e irá **reproduzir a página da incrível plataforma do Discord** colocando em prática todos os conceitos aprendidos até aqui, principalmente sobre **Responsividade no CSS**.

**Seja criativo(a) e dê a sua identidade para o Projeto. Lembre-se que para um(a) Profissional de Tecnologia é super importante ter um portfólio sólido e completo.**

 

## **Link do Figma**

Aqui deixamos o link do Protótipo no Figma apresentado pela Expert durante o Desafio para que você o tenha como referência:

**[Desafio de Responsividade](https://www.figma.com/file/NRBYrG5d4DSzObv7dpTqoM/Desafio-Responsividade---DIO)**

 

 

Bons estudos ![wink](https://app.digitalinnovation.one/static/ckeditor/ckeditor/plugins/smiley/images/wink_smile.png)