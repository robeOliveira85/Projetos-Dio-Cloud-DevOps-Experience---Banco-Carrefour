# Entendendo o Desafio

**Seja criativo(a)! Explore todos os conceitos que aprendemos nessa imersão e replique (ou melhore, porque não) este projeto prático. Para isso, seu próprio repositório e, com isso, aumente ainda mais seu portfólio de projetos no GitHub!**

 

*Dica: você pode dar um "fork" no Repositório do GitHub (App) para organizar suas alterações e evoluções, mantendo uma referência direta ao código original.*

 

## **GitHub**

Todo código-fonte desenvolvido para este conteúdo foi versionado no GitHub, no seguinte endereço:

https://github.com/digitalinnovationone/trilha-css-desafio-01

 

## **Figma**

O link do protótipo utilizado no Figma está disponível no seguinte endereço:

https://www.figma.com/file/3PiokoJj9IhGDnNiWAJbz7/DIO---Desafio-01?node-id=0%3A1

Bons estudos ![wink](https://app.digitalinnovation.one/static/ckeditor/ckeditor/plugins/smiley/images/wink_smile.png)

 