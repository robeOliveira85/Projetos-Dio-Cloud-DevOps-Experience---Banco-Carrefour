## [Formação CSS Web Developer](https://github.com/gmurilo/dio/tree/main/formacao-css-web-developer)

- ##### [Criando sua Primeira Landing Page com HTML e CSS](https://web.dio.me/lab/desafio-primeiros-passos-com-css/learning/401c88c4-c068-481c-99f0-7f0565542e90) :heavy_check_mark:

- ##### [Clonando a Página do Youtube com CSS](https://web.dio.me/lab/clonando-a-pagina-do-youtube-com-css/learning/91b4e191-a60e-43e2-a1af-dae6774e7261) :heavy_check_mark:

- ##### [Reproduzindo a Listagem do YouTube com Grid Layout no CSS](https://web.dio.me/lab/reproduzindo-a-listagem-do-youtube-com-grid-layout-no-css-grid-figma/learning/70a8e08d-a407-43f6-a41e-22d21e17f345) :heavy_check_mark:

- ##### [Construindo um Layout Responsivo Para o Site do Discord Com CSS](https://web.dio.me/lab/construindo-um-layout-responsivo-para-o-site-do-discord-com-css-responsividade-figma/learning/7d160ecd-2b79-4bf1-b356-b6c4a0119355) :heavy_check_mark:
 
