# Desafio de Projeto: Publicando Seu Portfólio Profissional no GitHub Pages]

Utilizando o fork que está na pasta exemplo, fiz o meu portfólio (não gosto de designer, então apenas clonei).
### O que foi modificado ?

- ###### Fiz modificações nas referências dos links para não puxar o path raiz e sim o path de referência incluindo o . na frente dos links com /;
- ###### Comecei a mexer no CSS para criar uma novo modelo de Template;