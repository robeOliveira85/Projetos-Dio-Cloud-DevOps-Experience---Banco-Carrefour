# Desafio de Projeto: Publicando Seu Portfólio Profissional no GitHub Pages]

Utilizando o fork que está na pasta exemplo, fiz o meu portfólio (não gosto de designer, então apenas clonei).
### O que foi modificado ?

- ###### Fiz um ajuste no javascript, pra caso a pessoa execute localment puxar um endereço "externo" e não a referência local;
- ###### Inclui alguns novos ícones;