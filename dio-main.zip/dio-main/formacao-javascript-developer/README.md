# [Formação JavaScript Developer](https://web.dio.me/track/formacao-javascript-developer)

- ##### [Construindo uma Pokédex com JavaScript](https://web.dio.me/project/construindo-uma-pokedex-com-javascript/learning/d3684309-5d5c-45d5-9715-c29127d65612) :heavy_check_mark:

- ##### [Publicando Seu Portfólio Profissional no GitHub Pages](https://web.dio.me/lab/publicando-seu-portfolio-profissional-no-github-pages/learning/b500f45d-f17f-49f0-8f1c-e7eceb79a8e2) :heavy_check_mark:
